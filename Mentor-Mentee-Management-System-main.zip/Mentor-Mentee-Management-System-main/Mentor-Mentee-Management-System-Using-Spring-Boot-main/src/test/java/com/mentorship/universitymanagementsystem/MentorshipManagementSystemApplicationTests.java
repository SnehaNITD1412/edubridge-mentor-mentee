package com.mentorship.universitymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
